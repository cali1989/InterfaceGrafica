async function buscarDireccion() {
  const direccion = document.getElementById('direccionInput').value.trim();
  if (!direccion) return alert('Por favor, ingresa una dirección.');

  try {
    const res = await axios.get('https://servicios.usig.buenosaires.gob.ar/normalizar', {
      params: { direccion, geocodificar: true, srid: 4326 },
    });
    mostrarResultados(res.data);
  } catch {
    alert('Error al obtener la dirección.');
  }
}

function limpiarResultados() {
  document.getElementById('resultados').innerHTML = '';
}

function mostrarResultados(data) {
  const resultados = document.getElementById('resultados');
  if (!data.direccionesNormalizadas?.length) {
    resultados.innerHTML = '<p class="text-danger">No se encontraron resultados.</p>';
    return;
  }

  resultados.innerHTML = data.direccionesNormalizadas.map(d => `
    <div class="result-item">
      <p><strong>Dirección:</strong> ${d.direccion}</p>
      <p><strong>Localidad:</strong> ${d.nombre_localidad || 'No disponible'}</p>
      <p><strong>Partido:</strong> ${d.nombre_partido || 'No disponible'}</p>
      <p><strong>Coordenadas:</strong> Lat: ${d.coordenadas?.y || 'No disponible'}, Lng: ${d.coordenadas?.x || 'No disponible'}</p>
    </div>
  `).join('');
}
